print("Running matching_name.py as", __name__)
from matching_name import submodule
